package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Comuna{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_comuna;

    @Column(name = "comuna", length = 50, unique = true, nullable = false)
    private String comuna;
    
}